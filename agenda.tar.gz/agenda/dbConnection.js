const MongoClient = require('mongodb').MongoClient

// Connection URL
const url = 'mongodb://localhost:27017';
// Database Name
const dbName = 'agenda';

//Fonction correspondant à l'application et le rappel de la BDD

const dbConnection = function(rappel){
    //RAPPEL = Math.sqrt
        MongoClient.connect(url, function(err, client) {
          if (err) {
            return
          }
          console.log('Connected successfully to server')
          const db = client.db(dbName)
          rappel(db)
          client.close()
      })
  }

  module.exports = dbConnection