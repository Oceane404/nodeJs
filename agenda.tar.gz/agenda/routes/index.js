var express = require('express');
var router = express.Router();

const dbConnection = require('../dbConnection')


const findContact = function(db, callback) {
  db.collection('contacts')
    .find({})
    .toArray(function(err, docs){
      console.log(docs)
      callback(docs)
  })
}


// GET Accueil
router.get('/', function(req, res, next) {
  
  dbConnection(function(db) {
    console.log('req.user');
    
      findContact(db, function(contacts){
        console.log(contacts)
        res.render('index', { title: 'Repertoire', contacts: contacts });
      })
  })    
})

//Ajouter un contact dans la base de données

router.post('/contacts', function(req, res, next) {
  console.log(req.body.message)
  console.log(id)
    
  dbConnection(function(db) {
    db.collection('contacts')
        .insertOne({
          contacts: req.body.message, 
          user: {
            id : req.user._id,  //new ObjectId("5e18751b44bea30ff15dbad3"),
            name : req.user.name, //'admin',
            avatar : req.user.avatar,
            phoneNumberF : req.user.phoneNumberF,
            phoneNumberM : req.user.phoneNumberM,
            email1 : req.user.email1,
            email2 : req.user.email2
        },
        date : new Date(),
        comments:[]
      })
  })
})

module.exports = router;



//Supprimer un contact
/*
{% if (contact.name) == (contacts.contact.name) %}
          <div class="modif">
            <button type="submit" class="btn btn-primary" onclick="suppress('{{ contacts._id }}')" >Supprimer</button>
          </div>

{% endif %}*/