var express = require('express')
var router = express.Router()

const dbConnection = require('../dbConnection')

const ObjectId = require('mongodb').ObjectId

const MongoClient = require('mongodb').MongoClient

// Connection URL
const url = 'mongodb://localhost:27017';
// Database Name
const dbName = 'agenda';



//Ajouter un nouveau contact dans la base de données

router.post('/', function(req, res, next) {
    console.log(req.body.message)
      
    dbConnection(function(db) {
      db.collection('contacts')
          .insertOne({
            contacts: req.body.message, 
            user: {
            id : req.session.user._id,  //new ObjectId("5e146ba2dde3b97089aecf43"),
            name : req.session.user.name, //'oceane2',
            avatar : 'req.session.user.avatar',
            phoneNumberF :'req.session.user.phoneNumberF',
            phoneNumberM : 'req.session.user.phoneNumberM',
            email1 : 'req.session.user.email1',
            email2 : 'req.session.user.email2'
          },
          date : new Date(),
          comments:[]
        })
    })
  })


  //Récupérer l'id d'un contact pour pouvoir le modifier
  router.get('/:id', function(req, res, next){
    console.log(req.params.id)
    

    dbConnection(function(db) {
      db.collection('contacts')
          .findOne({_id: new ObjectId(req.params.id)}, null, function(err, contacts) {
              if (err) {
                  return
              }
              console.log(contacts)
              res.render('contacts', { title: 'Edition', contacts: contacts });
          })
        })
    })


//Mise à jour du contact
  
router.put('/:id', function(req, res, next){
  dbConnection(function(db) {
    db.collection('contacts')
        .updateOne({_id: new ObjectId(req.params.id)}, {$set:{contacts:req.body.message}})
           res.end()
      })
})


//Supprimer un contact
router.delete('/:id', function (req, res, next) {
dbConnection(function (db) {
db.collection('contacts')
    .deleteOne({ _id: new ObjectId(req.params.id) })
res.end();
})
})


//Ajouter un commentaire/une note

router.get('/:id/comments', function (req, res, next) {
  let comments = []
  MongoClient.connect(url, function (err, client) {
    if (err) {
      return
    }
    console.log('Connected successfully to server')
  
    const db = client.db(dbName)
  
      db.collection('contacts')
        .findOne({_id: new ObjectId(req.params.id)}, null, function (err, contacts) {
          contacts.comments.forEach(function (comment) {
            db.collection('contacts')
              .findOne({_id: comment}, null, function (err, contactComment) {
                console.log(err)
                console.log(contactComment)
                comments.push(contactComment)
              })
          })
  
          console.log(comments)
          res.render('comments', {comments: comments})
        })
    // client.close()
  })
  })
  
  
  router.post('/:id/comments', function (req, res, next) {
  dbConnection(function(db) {
    db.collection('contacts')
        .insertOne({
          contacts: req.body.comment, 
          user: {
            id : req.session.user._id,  //
            name : req.session.user.name, //'admin',
            avatar : req.session.user.avatar,
            phoneNumberF :req.session.user.phoneNumberF,
            phoneNumberM : req.session.user.phoneNumberM,
            email1 : req.session.user.email1,
            email2 : req.session.user.email2
        },
        date : new Date(),
        comments:[],
      }, null, function(err, result) {
        db.collection('contacts')
        .updateOne({_id: new ObjectId(req.params.id)}, {$push: {comments: result.insertedId}})
            res.end()
      })
    })
  })
  

//Mise à jour du contact

    router.put('/:id', function(req, res, next){
      dbConnection(function(db) {
        db.collection('contacts')
            .updateOne({_id: new ObjectId(req.params.id)}, {$set:{contacts:req.body.message}})
               res.end()
          })
    })


//Supprimer un contact
router.delete('/:id', function (req, res, next) {
dbConnection(function (db) {
    db.collection('contacts')
        .deleteOne({ _id: new ObjectId(req.params.id) })
    res.end();
})
})

module.exports = router

