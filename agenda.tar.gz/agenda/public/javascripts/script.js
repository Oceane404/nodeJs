const form = document.getElementById('newContact')


//Update

const update = document.getElementById('newContact')

if (update) {
    update.addEventListener('submit',function(event){
        event.preventDefault()

        console.log(event)

        let contactContent = document.querySelector("#edit-contact").value;
        console.log(contactContent)
    if(contactContent.length > 200){
        alert('limite de caractère dépassée')
        } else {
            fetch('',{
                method:'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({message: contactContent, user:'me'})
            })

            .then(function(response){
                if (response.status === 200) {
                    location.href = '/'
                }
                console.log(response)
            })
        }
    })

}

//Effacer un contact
const suppress = function(id) {
    fetch('/contacts/' + id, {
        method: 'DELETE'
    })
    .then(function(){window.location.reload()});
};
